import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cup-event',
  templateUrl: './cup-event.component.html',
  styleUrls: ['./cup-event.component.css']
})
export class CupEventComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
