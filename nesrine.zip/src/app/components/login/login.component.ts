import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  errorMsg: string;
  constructor(
    private formBuilder: FormBuilder,
    private router: Router) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: ["", [Validators.required, Validators.email]],
      pwd: ["", [Validators.required]],
    })
  }

  login() {
    let user = this.loginForm.value;
    let users = JSON.parse(localStorage.getItem("users") || "[]");
    let findedUser;
    for (let i = 0; i < users.length; i++) {
      if (users[i].email == user.email && users[i].pwd == user.pwd) {
        // Success 
        localStorage.setItem("connectedUserId", users[i].id);
        findedUser = users[i];
        break;
      }
    }
    if (findedUser) {
      if (findedUser.role == "admin") {
        this.router.navigate(["admin"]);
      } else {
        this.router.navigate([""]);
      }
    } else {
      this.errorMsg = "Please Check Email/Pwd";
    }
  }

}
