import { AsterixPipe } from './asterix.pipe';

describe('AsterixPipe', () => {
  it('create an instance', () => {
    const pipe = new AsterixPipe();
    expect(pipe).toBeTruthy();
  });
});
